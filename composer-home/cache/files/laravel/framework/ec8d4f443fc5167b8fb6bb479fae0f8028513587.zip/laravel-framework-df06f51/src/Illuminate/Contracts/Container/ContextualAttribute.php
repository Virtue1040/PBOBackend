<?php

namespace Illuminate\Contracts\Container;

interface ContextualAttribute
{
    //
}
